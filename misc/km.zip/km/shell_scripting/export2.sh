#!/bin/sh

echo "$var1"
echo "$var2"
