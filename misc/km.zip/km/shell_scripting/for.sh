#!/bin/sh


# for control statment example


for i in 0 1 2
do
	echo $i
done

