#!/bin/bash

#shell variables examples

echo "user name:$USER"

myvar=kernel

echo $myvar
echo "$myvar"
echo '$myvar'
echo \$myvar
echo \$myvar:$myvar

#echo Enter some text
#read myvar

#echo '$myvar' now equals $myvar
exit 0
