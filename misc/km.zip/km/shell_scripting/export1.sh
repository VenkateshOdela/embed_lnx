#!/bin/sh

#echo "user name:$USER"

# the below command exports all the variables thereafter
# set -a


var1=12
var2=34

./export2.sh

