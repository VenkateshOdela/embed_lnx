Linux System Programming Class Notes & Examples prepared by Kernel Masters:
--------------------------------------------------------------------------

Description of various folders:

+ File: File management stuff for basic & advanced file operations.
+ Process: Process Management stuff for process system calls, signals & Threads.
+ Sync: Synchronization stuff for Thread & Process synchronization.
+ IPC: Inter Process Communicaiton stuff for Pipes, Name pipes, Shared Memory and socket programming

